#!/usr/bin/env python3
"""
Bat File Editor - Standalone Desktop IDE
Fully featured IDE written in pure Python.
Includes real-time syntax highlighting, interactive Command Reference Guide,
fully simulated interactive DOS Command Prompt, and a Gemini AI Copilot Sidebar!
"""

import os
import sys
import re
import json
import random
import tempfile
import threading
import datetime
import base64
import urllib.request
import urllib.error
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

# Slate-Dark Theme Palette
BG_MAIN = "#0f172a"      # slate-900
BG_PANEL = "#1e293b"     # slate-800
BG_TEXT = "#020617"      # slate-950
FG_TEXT = "#f8fafc"      # slate-50
FG_MUTED = "#94a3b8"     # slate-400
ACCENT_BLUE = "#38bdf8"  # sky-400
ACCENT_GREEN = "#4ade80" # emerald-400
ACCENT_AMBER = "#fbbf24" # amber-400
ACCENT_PINK = "#f472b6"  # pink-400
ACCENT_RED = "#f87171"   # red-400

# Commands Database
BATCH_COMMANDS = [
    {
        "name": "ECHO", "category": "Control", 
        "syntax": "ECHO [ON | OFF] \\nECHO [message]", 
        "description": "Displays messages or turns command echoing on or off.",
        "example": "@echo off\\necho Hello, World!\\necho. -- empty line"
    },
    {
        "name": "SET", "category": "Variables", 
        "syntax": "SET var=value \\nSET /P var=prompt \\nSET /A var=expr", 
        "description": "Sets or removes environment variables. Supports user input (/P) and math calculations (/A).",
        "example": "set NAME=Guest\\nset /p AGE=Enter your age: \\nset /a RESULT=5 * 10"
    },
    {
        "name": "IF", "category": "Logic", 
        "syntax": "IF [NOT] condition command", 
        "description": "Performs conditional processing in batch programs. Can check variable values or file existence.",
        "example": "if \\\"%AGE%\\\"==\\\"18\\\" echo You are exactly eighteen!\\nif exist log.txt echo File exists!"
    },
    {
        "name": "GOTO", "category": "Logic", 
        "syntax": "GOTO label", 
        "description": "Directs CMD to jump to a labeled line starting with a colon (:).",
        "example": "goto :menu\\n:menu\\necho Main Menu"
    },
    {
        "name": "PAUSE", "category": "Control", 
        "syntax": "PAUSE", 
        "description": "Suspends execution of the script and displays 'Press any key to continue . . .'",
        "example": "echo Wait here...\\npause"
    },
    {
        "name": "CHOICE", "category": "Input", 
        "syntax": "CHOICE [/C choices] [/M text]", 
        "description": "Prompts user to choose one of standard single-character options. Returns choice index in ERRORLEVEL.",
        "example": "choice /c YNC /m \\\"Do you want to continue\\\"\\nif errorlevel 3 goto cancel\\nif errorlevel 2 goto no\\nif errorlevel 1 goto yes"
    },
    {
        "name": "TIMEOUT", "category": "Control", 
        "syntax": "TIMEOUT /T seconds [/NOBREAK]", 
        "description": "Pauses command processor for a specified number of seconds.",
        "example": "timeout /t 5"
    },
    {
        "name": "CLS", "category": "Utility", 
        "syntax": "CLS", 
        "description": "Clears the active command prompt terminal screen.",
        "example": "cls"
    },
    {
        "name": "COLOR", "category": "Utility", 
        "syntax": "COLOR [attr]", 
        "description": "Sets default background and foreground console colors using 2 hex digits.",
        "example": "color 0a -- black bg, light green text\\ncolor 1f -- blue bg, bright white text"
    },
    {
        "name": "TITLE", "category": "Utility", 
        "syntax": "TITLE [string]", 
        "description": "Sets the window title for the terminal session.",
        "example": "title My Script v1.0"
    },
    {
        "name": "EXIT", "category": "Control", 
        "syntax": "EXIT [/B] [exitCode]", 
        "description": "Quits the batch script program or terminal session. /B exits the script only.",
        "example": "exit /b 0"
    }
]

# Preset Script Examples
BATCH_EXAMPLES = [
    {
        "title": "Interactive Main Menu",
        "code": "@echo off\\ntitle Interactive System Utility\\ncolor 1f\\n\\n:menu\\ncls\\necho ======================================\\necho          SYSTEM ADMIN MENU\\necho ======================================\\necho  1. Test Internet Connectivity\\necho  2. Show Running System Diagnostics\\necho  3. Exit Application\\necho ======================================\\nchoice /c 123 /m \\\"Enter your choice (1-3):\\\"\\n\\nif errorlevel 3 goto exit\\nif errorlevel 2 goto info\\nif errorlevel 1 goto pingtest\\n\\n:pingtest\\ncls\\necho [TEST] Pinging local server diagnostics...\\nping 127.0.0.1 -n 3\\npause\\ngoto menu\\n\\n:info\\ncls\\necho [INFO] User Profile: %USERNAME%\\necho [INFO] System Date:  %DATE% - %TIME%\\npause\\ngoto menu\\n\\n:exit\\ncls\\necho Exiting application. Goodbye!\\npause\\nexit /b 0"
    },
    {
        "title": "Smart Folder Backup",
        "code": "@echo off\\ntitle Smart Backup Utility\\ncolor 0e\\ncls\\necho ======================================\\necho         AUTOMATED COPY UTILITY\\necho ======================================\\necho.\\nset /p src=\\\"Enter source folder path: \\\"\\nset /p dest=\\\"Enter backup destination folder: \\\"\\n\\nif not exist \\\"%src%\\\" (\\n    echo [ERROR] Source folder \\\"%src%\\\" does not exist!\\n    pause\\n    exit /b 1\\n)\\n\\necho [INFO] Preparing directories...\\nif not exist \\\"%dest%\\\" (\\n    mkdir \\\"%dest%\\\"\\n)\\n\\necho [INFO] Copying files securely...\\ncopy \\\"%src%\\\"\\\\* \\\"%dest%\\\" /y\\necho Backup Completed successfully!\\npause"
    },
    {
        "title": "Dynamic CMD Matrix Effect",
        "code": "@echo off\\ntitle CMD Matrix Screen Saver\\ncolor 02\\ncls\\necho Press any key to enter the digital stream...\\npause > nul\\n\\n:matrix\\necho %random% %random% %random% %random% %random% %random% %random% %random%\\ngoto matrix"
    }
]

class BatchInterpreter:
    """Thread-safe simulator engine to execute batch scripts line-by-line."""
    def __init__(self, log_callback, ui_callback):
        self.log = log_callback
        self.ui = ui_callback
        self.variables = {
            "USERNAME": "GuestUser",
            "DATE": "2026-06-26",
            "TIME": "15:15:00",
            "ERRORLEVEL": "0"
        }
        self.labels = {}
        self.lines = []
        self.pc = 0
        self.echo_on = True
        self.running = False
        self.waiting_type = None  # "pause", "input", "choice"
        self.target_variable = ""
        self.choices = []
        self.input_event = threading.Event()
        self.user_input = ""

    def load_script(self, code):
        self.lines = [line.strip() for line in code.splitlines()]
        self.labels = {}
        for idx, line in enumerate(self.lines):
            match = re.match(r"^:([A-Za-z0-9_-]+)", line)
            if match:
                self.labels[match.group(1).lower()] = idx
        self.pc = 0
        self.echo_on = True
        self.variables["ERRORLEVEL"] = "0"

    def start_running(self):
        self.running = True
        threading.Thread(target=self._run_loop, daemon=True).start()

    def _run_loop(self):
        try:
            while self.running and self.pc < len(self.lines):
                line = self.lines[self.pc]
                self.pc += 1
                
                # Strip leading whitespace and check comment
                s_line = line.strip()
                if not s_line or s_line.lower().startswith("rem") or s_line.startswith("::"):
                    continue
                    
                is_silent = s_line.startswith("@")
                cmd = s_line[1:].strip() if is_silent else s_line
                
                if self.echo_on and not is_silent:
                    self.log("C:\\\\Users\\\\Guest>" + s_line + "\\n", "input")
                    
                expanded_cmd = self._expand_vars(cmd)
                self._execute_single_cmd(expanded_cmd)
                
            if self.pc >= len(self.lines) and self.running:
                self.log("\\n[Script completed successfully]\\n", "info")
                self.log("C:\\\\Users\\\\Guest>", "output")
        except Exception as e:
            self.log(f"\\n[Runtime Error: {str(e)}]\\n", "error")
        finally:
            self.running = False
            self.ui("idle")

    def _expand_vars(self, text):
        def repl(m):
            var_name = m.group(1).upper()
            if var_name == "RANDOM":
                return str(random.randint(0, 32767))
            return self.variables.get(var_name, f"%{m.group(1)}%")
        return re.sub(r"%([A-Za-z0-9_-]+)%", repl, text)

    def _execute_single_cmd(self, cmd_text):
        cmd_lower = cmd_text.lower().strip()
        
        # ECHO OFF/ON
        if cmd_lower == "echo off" or cmd_lower == "@echo off":
            self.echo_on = False
            return
        elif cmd_lower == "echo on" or cmd_lower == "@echo on":
            self.echo_on = True
            return
            
        # ECHO msg
        if cmd_lower.startswith("echo"):
            msg = cmd_text[4:].strip()
            if msg == ".":
                self.log("\\n", "output")
            else:
                self.log(msg + "\\n", "output")
            return
            
        # CLS
        if cmd_lower == "cls":
            self.log("clear_screen", "command")
            return
            
        # COLOR
        if cmd_lower.startswith("color"):
            arg = cmd_text[5:].strip()
            self.log(f"color:{arg}", "command")
            return
            
        # TITLE
        if cmd_lower.startswith("title"):
            arg = cmd_text[5:].strip()
            self.ui(f"title:{arg}")
            return
            
        # PAUSE
        if cmd_lower == "pause":
            self.log("Press any key to continue . . .\\n", "info")
            self.waiting_type = "pause"
            self.input_event.clear()
            self.ui("wait_pause")
            self.input_event.wait()
            return
            
        # SET
        if cmd_lower.startswith("set "):
            expr = cmd_text[4:].strip()
            
            # SET /P (Prompt)
            if expr.lower().startswith("/p "):
                parts = expr[3:].strip().split("=", 1)
                if len(parts) == 2:
                    var_name, prompt = parts[0].strip(), parts[1].strip()
                    self.target_variable = var_name
                    self.log(prompt, "output")
                    self.waiting_type = "input"
                    self.input_event.clear()
                    self.ui("wait_input")
                    self.input_event.wait()
                    self.variables[var_name.upper()] = self.user_input
                return
                
            # SET /A (Math)
            elif expr.lower().startswith("/a "):
                parts = expr[3:].strip().split("=", 1)
                if len(parts) == 2:
                    var_name, math_expr = parts[0].strip(), parts[1].strip()
                    try:
                        safe_expr = re.sub(r"[A-Za-z0-9_-]+", lambda m: self.variables.get(m.group(0).upper(), m.group(0)), math_expr)
                        safe_expr = re.sub(r"[^0-9\\+\\-\\*\\/\\(\\)\\s]", "", safe_expr)
                        self.variables[var_name.upper()] = str(eval(safe_expr))
                    except:
                        self.variables[var_name.upper()] = "0"
                return
                
            # Regular SET
            parts = expr.split("=", 1)
            if len(parts) == 2:
                self.variables[parts[0].strip().upper()] = parts[1].strip()
            return
            
        # GOTO
        if cmd_lower.startswith("goto "):
            label = cmd_text[5:].strip().lower()
            if label.startswith(":"):
                label = label[1:]
            if label in self.labels:
                self.pc = self.labels[label]
            else:
                self.log(f"The system cannot find the batch label specified - {label}\\n", "error")
            return
            
        # CHOICE
        if cmd_lower.startswith("choice"):
            choices = ["Y", "N"]
            prompt = "Select option"
            parts = cmd_text.split()
            for idx, p in enumerate(parts):
                if p.lower() == "/c" and idx + 1 < len(parts):
                    choices = [char.upper() for char in parts[idx+1].replace('"', '')]
                elif p.lower() == "/m" and idx + 1 < len(parts):
                    prompt = " ".join(parts[idx+1:]).replace('"', '')
                    break
            self.log(f"{prompt} ({','.join(choices)}): ", "output")
            self.waiting_type = "choice"
            self.choices = choices
            self.input_event.clear()
            self.ui("wait_choice")
            self.input_event.wait()
            return
            
        # IF condition
        if cmd_lower.startswith("if "):
            expr = cmd_text[3:].strip()
            is_not = False
            if expr.lower().startswith("not "):
                is_not = True
                expr = expr[4:].strip()
                
            match = re.match(r'^"?([^"]*)"?\\s*==\\s*"?([^"]*)"?\\s+(.+)$', expr, re.IGNORECASE)
            if match:
                left, right, action = match.groups()
                is_equal = (left == right)
                if is_not:
                    is_equal = not is_equal
                if is_equal:
                    self._execute_single_cmd(action)
                return
                
            match_exist = re.match(r'^exist\\s+"?([^"]*)"?\\s+(.+)$', expr, re.IGNORECASE)
            if match_exist:
                fpath, action = match_exist.groups()
                exists = os.path.exists(fpath)
                if is_not:
                    exists = not exists
                if exists:
                    self._execute_single_cmd(action)
                return
                
        # TIMEOUT
        if cmd_lower.startswith("timeout"):
            m = re.search(r"/t\\s+(\\d+)", cmd_text, re.IGNORECASE)
            sec = int(m.group(1)) if m else 3
            self.log(f"Waiting for {sec} seconds. Press any key to skip...\\n", "info")
            self.waiting_type = "pause"
            self.input_event.clear()
            self.ui("wait_pause")
            self.input_event.wait(timeout=sec)
            return
            
        # EXIT
        if cmd_lower == "exit" or cmd_lower == "exit /b":
            self.running = False
            return
            
        # External commands
        self.log(f"[External Utility Executed: {cmd_text}]\\n", "info")

class BatchEditorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Bat File Editor - Standalone IDE")
        self.root.geometry("1150x720")
        self.root.configure(bg=BG_MAIN)
        self.app_base_dir = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
        icon_path = os.path.join(self.app_base_dir, "bat_file_explorer.ico")
        icon_png = os.path.join(self.app_base_dir, "bat.png")
        self.tk_icon = None
        if os.path.exists(icon_path):
            try:
                self.root.iconbitmap(icon_path)
            except Exception:
                pass
        if os.path.exists(icon_png):
            try:
                self.tk_icon = tk.PhotoImage(file=icon_png)
                self.root.iconphoto(False, self.tk_icon)
            except Exception:
                self.tk_icon = None
        self.current_file = None
        self.config = self._load_config()
        self.backup_dir = os.path.join(os.getcwd(), "backups")
        os.makedirs(self.backup_dir, exist_ok=True)
        self._backup_dirty = False
        self._backup_interval_ms = 60000

        # App menu bar
        menubar = tk.Menu(self.root)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New", command=self.new_file, accelerator="Ctrl+N")
        file_menu.add_command(label="Open...", command=self.open_file, accelerator="Ctrl+O")
        file_menu.add_command(label="Save", command=self.save_file, accelerator="Ctrl+S")
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="Help Contents", command=self.show_help, accelerator="F1")
        help_menu.add_command(label="About", command=self.show_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        self.root.config(menu=menubar)

        self.root.bind("<Control-n>", lambda event: self.new_file())
        self.root.bind("<Control-o>", lambda event: self.open_file())
        self.root.bind("<Control-s>", lambda event: self.save_file())
        self.root.bind("<F1>", lambda event: self.show_help())
        
        # Configure overall ttk styles
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=BG_MAIN, borderwidth=0)
        style.configure("TNotebook.Tab", background=BG_PANEL, foreground=FG_MUTED, font=("Segoe UI", 9, "bold"), padding=(10, 4))
        style.map("TNotebook.Tab", background=[("selected", BG_MAIN)], foreground=[("selected", ACCENT_BLUE)])
        style.configure("TCombobox", fieldbackground=BG_TEXT, background=BG_PANEL, foreground=FG_TEXT, arrowcolor=ACCENT_BLUE)
        
        # Build layout
        self._build_interface()
        
        # Initialize thread-safe interpreter
        self.interpreter = BatchInterpreter(self._log_to_console, self._handle_interpreter_ui)
        
        # Initialize default code
        self.editor.insert("1.0", BATCH_EXAMPLES[0]["code"])
        self.perform_highlighting()

    def _load_config(self):
        try:
            if os.path.exists("batch_studio_config.json"):
                with open("batch_studio_config.json", "r") as f:
                    config = json.load(f)
                encoded = config.get("api_key", "")
                if encoded:
                    try:
                        decoded = base64.b64decode(encoded, validate=True).decode("utf-8")
                        config["api_key"] = decoded
                    except Exception:
                        # Preserve legacy plain API key values when decoding fails
                        config["api_key"] = encoded
                return config
        except:
            pass
        return {"api_key": ""}

    def _save_config(self):
        try:
            config = self.config.copy()
            key = config.get("api_key", "")
            if key:
                config["api_key"] = base64.b64encode(key.encode("utf-8")).decode("utf-8")
            with open("batch_studio_config.json", "w") as f:
                json.dump(config, f)
        except:
            pass

    def _build_interface(self):
        # 1. Main toolbar
        toolbar = tk.Frame(self.root, bg=BG_PANEL, height=45)
        toolbar.pack(fill=tk.X, side=tk.TOP, padx=5, pady=5)
        
        btn_config = {"bg": BG_MAIN, "fg": FG_TEXT, "activebackground": ACCENT_BLUE, "activeforeground": BG_MAIN, "bd": 0, "padx": 10, "pady": 4, "font": ("Segoe UI", 9, "bold")}
        
        logo_path = os.path.join(self.app_base_dir, "bat.png")
        self.logo_img = None
        if os.path.exists(logo_path):
            try:
                self.logo_img = tk.PhotoImage(file=logo_path)
                tk.Label(toolbar, image=self.logo_img, bg=BG_PANEL).pack(side=tk.LEFT, padx=(6, 8), pady=4)
            except Exception:
                self.logo_img = None

        tk.Button(toolbar, text="New File", command=self.new_file, **btn_config).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="Open File", command=self.open_file, **btn_config).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="Save File", command=self.save_file, **btn_config).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="Backup WIP", command=self.backup_wip, **btn_config).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="AI Copilot", command=self.show_ai_view, **btn_config).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="Help", command=self.show_help, **btn_config).pack(side=tk.LEFT, padx=5)

        self.backup_status_label = tk.Label(toolbar, text="Backup: up to date", bg=BG_PANEL, fg=ACCENT_GREEN, font=("Segoe UI", 9, "italic"))
        self.backup_status_label.pack(side=tk.RIGHT, padx=10)
        
        # Divider
        tk.Frame(toolbar, width=1, bg=FG_MUTED, height=20).pack(side=tk.LEFT, padx=10)
        
        tk.Button(toolbar, text="▶ Run Script", command=self.run_simulated_script, bg="#059669", fg="white", activebackground="#34d399", bd=0, padx=12, pady=4, font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=5)
        if sys.platform == "win32":
            tk.Button(toolbar, text="🪟 Run Native CMD", command=self.run_native_script, bg="#b45309", fg="white", activebackground="#f59e0b", bd=0, padx=12, pady=4, font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=5)
            
        tk.Label(toolbar, text="Examples:", bg=BG_PANEL, fg=FG_MUTED, font=("Segoe UI", 9)).pack(side=tk.RIGHT, padx=5)
        self.ex_combo = ttk.Combobox(toolbar, values=[e["title"] for e in BATCH_EXAMPLES], state="readonly", width=20)
        self.ex_combo.pack(side=tk.RIGHT, padx=5)
        self.ex_combo.bind("<<ComboboxSelected>>", self.load_example_selected)
        
        # 2. Main paned layout split
        self.main_pane = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, bg=BG_MAIN, bd=0, sashwidth=4)
        self.main_pane.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # --- LEFT SIDEPANEL: Command Guide ---
        left_side = tk.Frame(self.main_pane, bg=BG_PANEL, width=240)
        left_side.pack_propagate(False)
        self.main_pane.add(left_side)
        
        tk.Label(left_side, text="Command Guide", font=("Segoe UI", 11, "bold"), bg=BG_PANEL, fg=ACCENT_BLUE).pack(anchor=tk.W, padx=10, pady=8)
        
        # Search Box
        search_frame = tk.Frame(left_side, bg=BG_PANEL)
        search_frame.pack(fill=tk.X, padx=10, pady=3)
        tk.Label(search_frame, text="🔍", bg=BG_PANEL, fg=FG_MUTED).pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.filter_commands())
        self.search_entry = tk.Entry(search_frame, textvariable=self.search_var, bg=BG_TEXT, fg=FG_TEXT, bd=1, insertbackground=FG_TEXT)
        self.search_entry.pack(fill=tk.X, expand=True, padx=5)
        
        # Listbox for commands
        self.cmd_listbox = tk.Listbox(left_side, bg=BG_TEXT, fg=FG_TEXT, selectbackground=ACCENT_BLUE, selectforeground=BG_MAIN, bd=0, font=("Consolas", 10))
        self.cmd_listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        self.cmd_listbox.bind("<<ListboxSelect>>", self.on_command_select)
        
        # Command Info Description
        self.info_box = tk.Text(left_side, bg=BG_TEXT, fg=FG_MUTED, wrap=tk.WORD, bd=0, height=8, font=("Segoe UI", 9))
        self.info_box.pack(fill=tk.X, side=tk.BOTTOM, padx=10, pady=10)
        
        btn_cmd_f = tk.Frame(left_side, bg=BG_PANEL)
        btn_cmd_f.pack(fill=tk.X, side=tk.BOTTOM, padx=10)
        tk.Button(btn_cmd_f, text="➕ Insert Code", command=self.insert_selected_command, bg=BG_MAIN, fg=FG_TEXT, activebackground=ACCENT_BLUE, bd=0, pady=4, font=("Segoe UI", 9, "bold")).pack(fill=tk.X)
        
        # --- MIDDLE PANEL: Center area with Editor / AI switch ---
        center_frame = tk.Frame(self.main_pane, bg=BG_MAIN)
        self.main_pane.add(center_frame)
        
        toggle_bar = tk.Frame(center_frame, bg=BG_PANEL, height=40)
        toggle_bar.pack(fill=tk.X, padx=5, pady=(0, 5))
        self.btn_view_editor = tk.Button(toggle_bar, text="Editor", command=self.show_editor_view, **btn_config)
        self.btn_view_editor.pack(side=tk.LEFT, padx=5)
        self.btn_view_ai = tk.Button(toggle_bar, text="AI Copilot", command=self.show_ai_view, **btn_config)
        self.btn_view_ai.pack(side=tk.LEFT, padx=5)
        
        self.editor_frame = tk.Frame(center_frame, bg=BG_MAIN, highlightthickness=2, highlightbackground=BG_PANEL)
        self.editor_frame.pack(fill=tk.BOTH, expand=True)
        
        self.editor_label = tk.Label(self.editor_frame, text="Script Editor (untitled.bat)", font=("Segoe UI", 10, "bold"), bg=BG_MAIN, fg=FG_TEXT)
        self.editor_label.pack(anchor=tk.W, pady=3)
        
        self.editor = tk.Text(self.editor_frame, bg=BG_TEXT, fg=FG_TEXT, insertbackground=FG_TEXT, undo=True, wrap=tk.NONE, font=("Consolas", 11), bd=0)
        self.editor.pack(fill=tk.BOTH, expand=True)
        self.editor.bind("<KeyRelease>", self.on_editor_change)
        
        # Setup highlight colors
        self.editor.tag_config("keyword", foreground=ACCENT_BLUE, font=("Consolas", 11, "bold"))
        self.editor.tag_config("comment", foreground=ACCENT_GREEN, font=("Consolas", 11, "italic"))
        self.editor.tag_config("variable", foreground=ACCENT_PINK)
        self.editor.tag_config("string", foreground=ACCENT_AMBER)
        self.editor.tag_config("label", foreground=ACCENT_RED, font=("Consolas", 11, "bold"))
        self.editor.tag_config("number", foreground="#c084fc")
        
        self.ai_frame = tk.Frame(center_frame, bg=BG_MAIN, highlightthickness=2, highlightbackground=BG_PANEL)
        
        ai_top = tk.Frame(self.ai_frame, bg=BG_PANEL)
        ai_top.pack(fill=tk.X, side=tk.TOP, padx=5, pady=5)
        tk.Label(ai_top, text="Gemini API Key:", bg=BG_PANEL, fg=FG_MUTED, font=("Segoe UI", 8)).pack(side=tk.LEFT, padx=3)
        self.api_entry = tk.Entry(ai_top, bg=BG_TEXT, fg=FG_TEXT, bd=1, show="*", width=18, insertbackground=FG_TEXT)
        self.api_entry.pack(side=tk.LEFT, padx=3, fill=tk.X, expand=True)
        self.api_entry.insert(0, self.config.get("api_key", ""))
        
        self.show_key = False
        tk.Label(ai_top, text="(stored encoded in config)", bg=BG_PANEL, fg=FG_MUTED, font=("Segoe UI", 7), anchor="w").pack(side=tk.LEFT, padx=6)
        self.btn_show_key = tk.Button(ai_top, text="👁", command=self.toggle_api_visibility, bg=BG_MAIN, fg=FG_TEXT, bd=0, padx=4)
        self.btn_show_key.pack(side=tk.LEFT, padx=2)
        tk.Button(ai_top, text="Save", command=self.save_api_key, bg=ACCENT_BLUE, fg=BG_MAIN, font=("Segoe UI", 8, "bold"), bd=0, padx=8).pack(side=tk.LEFT, padx=2)
        
        ai_buttons = tk.Frame(self.ai_frame, bg=BG_MAIN)
        ai_buttons.pack(fill=tk.X, side=tk.TOP, padx=5, pady=2)
        q_btn = {"bg": BG_PANEL, "fg": FG_TEXT, "activebackground": ACCENT_BLUE, "activeforeground": BG_MAIN, "bd": 0, "font": ("Segoe UI", 8, "bold"), "pady": 4}
        tk.Button(ai_buttons, text="🧠 Explain", command=lambda: self.trigger_ai_action("explain"), **q_btn).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        tk.Button(ai_buttons, text="🐞 Check Errors", command=lambda: self.trigger_ai_action("debug"), **q_btn).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        tk.Button(ai_buttons, text="✨ Optimize", command=lambda: self.trigger_ai_action("optimize"), **q_btn).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        
        self.ai_chat_log = tk.Text(self.ai_frame, bg=BG_TEXT, fg=FG_TEXT, wrap=tk.WORD, bd=0, state=tk.DISABLED, font=("Segoe UI", 9))
        self.ai_chat_log.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.ai_chat_log.tag_config("user", foreground=ACCENT_BLUE, font=("Segoe UI", 9, "bold"))
        self.ai_chat_log.tag_config("copilot", foreground=ACCENT_GREEN, font=("Segoe UI", 9, "bold"))
        self.ai_chat_log.tag_config("code", foreground="#e2e8f0", background="#1e293b", font=("Consolas", 9))
        self.ai_chat_log.tag_config("normal", foreground="#cbd5e1")
        
        chat_bar = tk.Frame(self.ai_frame, bg=BG_PANEL)
        chat_bar.pack(fill=tk.X, side=tk.BOTTOM, padx=5, pady=5)
        self.chat_entry = tk.Entry(chat_bar, bg=BG_TEXT, fg=FG_TEXT, bd=1, insertbackground=FG_TEXT)
        self.chat_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=3, pady=3)
        self.chat_entry.bind("<Return>", lambda e: self.send_ai_message())
        tk.Button(chat_bar, text="Send 🚀", command=self.send_ai_message, bg=ACCENT_BLUE, fg=BG_MAIN, font=("Segoe UI", 9, "bold"), bd=0, padx=12, pady=3).pack(side=tk.LEFT, padx=3)
        
        self.show_editor_view()
        self._schedule_auto_backup()
        
        # --- RIGHT PANEL: Simulated Console ---
        self.right_pane = tk.Frame(self.main_pane, bg=BG_PANEL, width=380)
        self.right_pane.pack_propagate(False)
        self.main_pane.add(self.right_pane)
        
        right_label = tk.Label(self.right_pane, text="Simulated CMD", bg=BG_PANEL, fg=ACCENT_BLUE, font=("Segoe UI", 10, "bold"))
        right_label.pack(anchor=tk.W, pady=8, padx=10)
        
        self.console_log = tk.Text(self.right_pane, bg="#020617", fg="#10b981", wrap=tk.CHAR, bd=0, state=tk.DISABLED, font=("Consolas", 10))
        self.console_log.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.console_log.tag_config("input", foreground=ACCENT_AMBER, font=("Consolas", 10, "bold"))
        self.console_log.tag_config("info", foreground=ACCENT_BLUE)
        self.console_log.tag_config("error", foreground=ACCENT_RED, font=("Consolas", 10, "bold"))
        self.console_log.tag_config("output", foreground="#f1f5f9")
        
        self.control_frame = tk.Frame(self.right_pane, bg=BG_PANEL, height=45)
        self.control_frame.pack(fill=tk.X, side=tk.BOTTOM)
        
        self.cmd_input_f = tk.Frame(self.control_frame, bg=BG_PANEL)
        self.cmd_input_f.pack(fill=tk.X, padx=5, pady=5)
        tk.Label(self.cmd_input_f, text=">", bg=BG_PANEL, fg=FG_MUTED, font=("Consolas", 11, "bold")).pack(side=tk.LEFT, padx=3)
        self.cmd_entry = tk.Entry(self.cmd_input_f, bg=BG_TEXT, fg=FG_TEXT, bd=1, insertbackground=FG_TEXT)
        self.cmd_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=3)
        self.cmd_entry.bind("<Return>", lambda e: self.send_manual_command())
        tk.Button(self.cmd_input_f, text="Send", command=self.send_manual_command, bg=BG_MAIN, fg=FG_TEXT, bd=0, padx=8).pack(side=tk.LEFT, padx=3)
        
        # Populate guide list
        self.filter_commands()
        
        # Print welcome in chat
        self._append_ai_message("Copilot", "Hello! I am your AI Batch Copilot. 💻\\nI can help write, explain, optimize, and check errors in Windows Batch (.bat) scripts.\\nHow can I assist you today?")

    # --- File Operations ---
    def new_file(self):
        self.editor.delete("1.0", tk.END)
        self.current_file = None
        self.editor_label.config(text="Script Editor (untitled.bat)")
        self.perform_highlighting()
        self._backup_dirty = False

    def open_file(self):
        path = filedialog.askopenfilename(filetypes=[("Batch Files", "*.bat;*.cmd"), ("All Files", "*.*")])
        if path:
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                self.editor.delete("1.0", tk.END)
                self.editor.insert("1.0", content)
                self.current_file = path
                self.editor_label.config(text=f"Script Editor ({os.path.basename(path)})")
                self.perform_highlighting()
                self._backup_dirty = False
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open file:\\n{str(e)}")

    def save_file(self):
        if not self.current_file:
            path = filedialog.asksaveasfilename(defaultextension=".bat", filetypes=[("Batch Files", "*.bat"), ("All Files", "*.*")])
            if not path:
                return
            self.current_file = path
            
        try:
            with open(self.current_file, "w", encoding="utf-8") as f:
                f.write(self.editor.get("1.0", tk.END).rstrip())
            self.editor_label.config(text=f"Script Editor ({os.path.basename(self.current_file)})")
            messagebox.showinfo("Saved", "Batch file saved successfully!")
            self._backup_dirty = False
            self._update_backup_status("Saved and synced", ACCENT_GREEN)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save file:\\n{str(e)}")
    def backup_wip(self, show_message=True):
        content = self.editor.get("1.0", tk.END).rstrip()
        if not content.strip():
            if show_message:
                messagebox.showwarning("Backup Skipped", "Editor is empty. Nothing to back up.")
            return

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(self.backup_dir, f"backup_wip_{timestamp}.bat")
        try:
            with open(backup_path, "w", encoding="utf-8") as f:
                f.write(content)
            if show_message:
                messagebox.showinfo("Backup Saved", f"Work-in-progress backup saved to:\n{backup_path}")
            self._backup_dirty = False
            self._update_backup_status(f"Last backup: {timestamp}", ACCENT_GREEN)
        except Exception as e:
            if show_message:
                messagebox.showerror("Backup Failed", f"Failed to save backup:\n{str(e)}")
            self._update_backup_status("Backup failed", ACCENT_RED)

    def _schedule_auto_backup(self):
        if self._backup_dirty:
            self.backup_wip(show_message=False)
        self.root.after(self._backup_interval_ms, self._schedule_auto_backup)

    def _update_backup_status(self, text, color=ACCENT_GREEN):
        if hasattr(self, 'backup_status_label'):
            self.backup_status_label.config(text=f"Backup: {text}", fg=color)

    def on_editor_change(self, event=None):
        self.perform_highlighting()
        self._backup_dirty = True
        self._update_backup_status("Unsaved edits", ACCENT_AMBER)

    def show_help(self):
        help_text = (
            "Bat File Editor Help:\n\n"
            "- New: Create a new batch script.\n"
            "- Open: Load an existing .bat or .cmd file.\n"
            "- Save: Save your current script to disk.\n"
            "- Run Script: Execute code in the integrated simulator.\n"
            "- Run Native CMD: Open the current script in Windows CMD.\n"
            "- AI Copilot: Ask the integrated AI to explain, debug, or optimize your batch code.\n"
            "- Use F1 for this help anytime.\n\n"
            "For interactive batch input, type responses into the console input box and press Enter.\n\n"
            "Made by Vampyer Knight 2026"
        )
        messagebox.showinfo("Help - Bat File Editor", help_text)

    def show_about(self):
        about_text = (
            "Bat File Editor\n"
            "A lightweight batch file editor with save, help, and integrated AI features.\n\n"
            "Designed to edit Windows .bat/.cmd scripts and simulate execution in a friendly interface.\n"
            "Use the AI Copilot tab to get code explanations, debugging tips, and optimization suggestions.\n"
            "Built with Python and Tkinter.\n\n"
            "Made by Vampyer Knight. 2026"
        )
        messagebox.showinfo("About Bat File Editor", about_text)

    def show_editor_view(self):
        if hasattr(self, 'ai_frame'):
            self.ai_frame.pack_forget()
        self.editor_frame.pack(fill=tk.BOTH, expand=True)
        self.btn_view_editor.config(bg=ACCENT_BLUE, fg=BG_MAIN)
        self.btn_view_ai.config(bg=BG_MAIN, fg=FG_TEXT)
        self.editor_label.config(text=f"Script Editor ({os.path.basename(self.current_file) if self.current_file else 'untitled.bat'})")

    def show_ai_view(self):
        if hasattr(self, 'editor_frame'):
            self.editor_frame.pack_forget()
        self.ai_frame.pack(fill=tk.BOTH, expand=True)
        self.btn_view_ai.config(bg=ACCENT_BLUE, fg=BG_MAIN)
        self.btn_view_editor.config(bg=BG_MAIN, fg=FG_TEXT)

    def load_example_selected(self, event=None):
        title = self.ex_combo.get()
        for ex in BATCH_EXAMPLES:
            if ex["title"] == title:
                self.editor.delete("1.0", tk.END)
                self.editor.insert("1.0", ex["code"])
                self.perform_highlighting()
                break

    # --- Highlighting Engine ---
    def perform_highlighting(self, event=None):
        if getattr(self, "_highlight_lock", False):
            return
        self._highlight_lock = True
        try:
            for tag in ["keyword", "comment", "variable", "string", "label", "number"]:
                self.editor.tag_remove(tag, "1.0", tk.END)
                
            lines = self.editor.get("1.0", tk.END).split("\\n")
            keywords = r"\\\\b(echo|set|if|for|goto|pause|choice|timeout|cls|color|title|exit|call|not|errorlevel)\\\\b"
            
            for l_idx, line in enumerate(lines, 1):
                # Match full comments first
                if re.match(r"^\\\\s*(rem\\\\b|::)", line, re.IGNORECASE):
                    self.editor.tag_add("comment", f"{l_idx}.0", f"{l_idx}.{len(line)}")
                    continue
                    
                # Match labels
                lbl = re.match(r"^\\\\s*:[A-Za-z0-9_-]+", line)
                if lbl:
                    self.editor.tag_add("label", f"{l_idx}.0", f"{l_idx}.{len(lbl.group(0))}")
                    
                # Double quotes strings
                for m in re.finditer(r'"[^"]*"', line):
                    self.editor.tag_add("string", f"{l_idx}.{m.start()}", f"{l_idx}.{m.end()}")
                    
                # %variables%
                for m in re.finditer(r'%[A-Za-z0-9_-]+%', line):
                    self.editor.tag_add("variable", f"{l_idx}.{m.start()}", f"{l_idx}.{m.end()}")
                # !variables!
                for m in re.finditer(r'![A-Za-z0-9_-]+!', line):
                    self.editor.tag_add("variable", f"{l_idx}.{m.start()}", f"{l_idx}.{m.end()}")
                    
                # CMD keywords
                for m in re.finditer(keywords, line, re.IGNORECASE):
                    pos = f"{l_idx}.{m.start()}"
                    tags = self.editor.tag_names(pos)
                    if "comment" not in tags and "string" not in tags:
                        self.editor.tag_add("keyword", pos, f"{l_idx}.{m.end()}")
                        
                # Numbers
                for m in re.finditer(r"\\\\b\\\\d+\\\\b", line):
                    pos = f"{l_idx}.{m.start()}"
                    tags = self.editor.tag_names(pos)
                    if "comment" not in tags and "string" not in tags:
                        self.editor.tag_add("number", pos, f"{l_idx}.{m.end()}")
        finally:
            self._highlight_lock = False

    # --- Reference Guide ---
    def filter_commands(self):
        query = self.search_var.get().lower()
        self.cmd_listbox.delete(0, tk.END)
        self.cmds_filtered = [c for c in BATCH_COMMANDS if query in c["name"].lower() or query in c["description"].lower()]
        for c in self.cmds_filtered:
            self.cmd_listbox.insert(tk.END, c["name"])

    def on_command_select(self, event):
        sel = self.cmd_listbox.curselection()
        if sel:
            cmd = self.cmds_filtered[sel[0]]
            self.info_box.config(state=tk.NORMAL)
            self.info_box.delete("1.0", tk.END)
            self.info_box.insert(tk.END, f"Command: {cmd['name']}\\n\\n", "keyword")
            self.info_box.insert(tk.END, f"Syntax:\\n{cmd['syntax']}\\n\\n", "variable")
            self.info_box.insert(tk.END, f"Description:\\n{cmd['description']}", "normal")
            self.info_box.config(state=tk.DISABLED)

    def insert_selected_command(self):
        sel = self.cmd_listbox.curselection()
        if sel:
            cmd = self.cmds_filtered[sel[0]]
            self.editor.insert(tk.INSERT, f"\\n{cmd['example']}\\n")
            self.perform_highlighting()

    # --- Simulated CMD Terminal Execution ---
    def run_simulated_script(self):
        code = self.editor.get("1.0", tk.END)
        self._clear_console()
        self._log_to_console("Microsoft Windows [Version 10.0.22621]\\n(Simulated Offline Environment)\\n\\n", "info")
        self.interpreter.load_script(code)
        self.interpreter.start_running()

    def run_native_script(self):
        if sys.platform != "win32":
            messagebox.showwarning("Platform Warning", "Native execution is only supported on Windows.")
            return
        code_content = self.editor.get("1.0", tk.END)
        try:
            fd_temp, temp_path = tempfile.mkstemp(suffix=".bat", text=True)
            with os.fdopen(fd_temp, "w", encoding="utf-8") as f:
                f.write(code_content)
            os.system(f'start cmd.exe /k "{temp_path}"')
        except Exception as e:
            messagebox.showerror("Error", f"Failed to run native script:\\n{str(e)}")

    def send_manual_command(self):
        text = self.cmd_entry.get().strip()
        if not text:
            return
        self.cmd_entry.delete(0, tk.END)
        
        # Feed back input to running interpreter
        if self.interpreter.running and self.interpreter.waiting_type in ["input", "choice", "pause"]:
            self._log_to_console(text + "\\n", "output")
            if self.interpreter.waiting_type == "choice":
                if text.upper() in self.interpreter.choices:
                    self.interpreter.user_input = text.upper()
                    self.interpreter.input_event.set()
                else:
                    self._log_to_console(f"Invalid choice. Option must be one of {','.join(self.interpreter.choices)}: ", "error")
            elif self.interpreter.waiting_type == "input":
                self.interpreter.user_input = text
                self.interpreter.input_event.set()
            elif self.interpreter.waiting_type == "pause":
                self.interpreter.input_event.set()
        else:
            # Command Prompt interactive typing simulation
            self._log_to_console(f"C:\\\\Users\\\\Guest>{text}\\n", "input")
            if text.lower() == "cls":
                self._clear_console()
            elif text.lower() == "help":
                self._log_to_console("Simulated Commands: cls, help, echo, title, color\\n", "info")
            elif text.lower().startswith("echo "):
                self._log_to_console(text[5:] + "\\n", "output")
            elif text.lower().startswith("color "):
                self._set_console_color(text[6:].strip())
            elif text.lower().startswith("title "):
                self.root.title(f"Bat File Editor - {text[6:].strip()}")
            else:
                self._log_to_console(f"'{text}' is not recognized as an internal or external command.\\n", "error")
            self._log_to_console("C:\\\\Users\\\\Guest>", "output")

    def _clear_console(self):
        self.console_log.config(state=tk.NORMAL)
        self.console_log.delete("1.0", tk.END)
        self.console_log.config(state=tk.DISABLED)

    def _log_to_console(self, msg, tag="output"):
        if msg == "clear_screen":
            self._clear_console()
            return
        if msg.startswith("color:"):
            self._set_console_color(msg[6:].strip())
            return
            
        self.console_log.config(state=tk.NORMAL)
        self.console_log.insert(tk.END, msg, tag)
        self.console_log.see(tk.END)
        self.console_log.config(state=tk.DISABLED)

    def _set_console_color(self, hex_code):
        bg_colors = {"0": "black", "1": "#1e3a8a", "2": "#15803d", "3": "#0369a1", "4": "#b91c1c", "5": "#6d28d9", "6": "#b45309", "7": "#cbd5e1", "f": "white"}
        fg_colors = {"0": "black", "1": "#3b82f6", "2": "#22c55e", "3": "#38bdf8", "4": "#ef4444", "5": "#a855f7", "6": "#f59e0b", "7": "#94a3b8", "f": "white", "a": "#4ade80", "e": "#fbbf24"}
        
        bg = "black"
        fg = "#10b981"
        if len(hex_code) == 2:
            bg = bg_colors.get(hex_code[0].lower(), bg)
            fg = fg_colors.get(hex_code[1].lower(), fg)
        self.console_log.config(bg=bg, fg=fg)

    def _handle_interpreter_ui(self, action):
        if action.startswith("title:"):
            self.root.title("Bat File Editor - " + action[6:])
        elif action == "wait_pause":
            # Show a temporary Floating Pause overlay button
            self.btn_pause = tk.Button(self.control_frame, text="Press Any Key to Continue Script Execution", command=self._resume_pause, bg=ACCENT_BLUE, fg=BG_MAIN, font=("Segoe UI", 9, "bold"), bd=0, pady=5)
            self.btn_pause.pack(fill=tk.X, padx=5, pady=5)
        elif action in ["wait_input", "wait_choice"]:
            # Focus prompt entry
            self.cmd_entry.focus()
        elif action == "idle":
            # Remove any residual pause buttons
            if hasattr(self, "btn_pause") and self.btn_pause:
                self.btn_pause.destroy()

    def _resume_pause(self):
        if hasattr(self, "btn_pause") and self.btn_pause:
            self.btn_pause.destroy()
        self.interpreter.input_event.set()

    # --- AI Copilot Sidebar Thread handlers ---
    def toggle_api_visibility(self):
        self.show_key = not self.show_key
        self.api_entry.config(show="" if self.show_key else "*")
        self.btn_show_key.config(text="🙈" if self.show_key else "👁")

    def save_api_key(self):
        key = self.api_entry.get().strip()
        self.config["api_key"] = key
        self._save_config()
        messagebox.showinfo("Saved", "Gemini API Key saved locally successfully!")

    def _append_ai_message(self, sender, text):
        self.ai_chat_log.config(state=tk.NORMAL)
        self.ai_chat_log.insert(tk.END, f"\\n{sender}:\\n", "copilot" if sender == "Copilot" else "user")
        
        # Simple parser to render block quotes nicely
        parts = text.split("```")
        for idx, part in enumerate(parts):
            if idx % 2 == 1:
                # Code block
                lines = part.split("\\n")
                code_lang = "bat"
                if lines and lines[0] in ["bat", "cmd", "python"]:
                    code_lang = lines[0]
                    part = "\\n".join(lines[1:])
                self.ai_chat_log.insert(tk.END, f"[Code Suggestion ({code_lang})]:\\n" + part.strip() + "\\n", "code")
            else:
                self.ai_chat_log.insert(tk.END, part, "normal")
                
        self.ai_chat_log.see(tk.END)
        self.ai_chat_log.config(state=tk.DISABLED)

    def trigger_ai_action(self, action):
        code = self.editor.get("1.0", tk.END).strip()
        if not code:
            messagebox.showwarning("Warning", "Editor is currently empty! Write or load a script first.")
            return
            
        prompt = ""
        if action == "explain":
            prompt = f"Explain this Windows Batch script step-by-step:\\n\\n```bat\\n{code}\\n```"
        elif action == "debug":
            prompt = f"Analyze this Windows Batch script for potential errors, logic bugs, or security vulnerabilities, and provide corrected code:\\n\\n```bat\\n{code}\\n```"
        elif action == "optimize":
            prompt = f"Optimize this Windows Batch script to be cleaner, safer, and use modern CMD features. Highlight the changes:\\n\\n```bat\\n{code}\\n```"
            
        self._send_ai_prompt(prompt)

    def send_ai_message(self):
        msg = self.chat_entry.get().strip()
        if not msg:
            return
        self.chat_entry.delete(0, tk.END)
        self._send_ai_prompt(msg)

    def _send_ai_prompt(self, prompt_text):
        key = self.api_entry.get().strip()
        if not key:
            messagebox.showwarning("API Key Required", "Please configure and save your Gemini API Key first to chat.")
            self.show_ai_view()
            self.api_entry.focus()
            return
            
        self._append_ai_message("You", prompt_text)
        self._append_ai_message("Copilot", "Thinking... please wait.")
        
        # Call Gemini in a non-blocking thread
        system_instruction = (
            "You are 'Batch Studio AI Copilot', an expert Windows Batch (.bat/.cmd) scripting assistant. "
            "Help users write, explain, debug, and optimize Windows CMD scripts. Always supply code "
            "blocks inside standard markdown (e.g. ```bat) when suggesting code modifications. "
            "Be extremely brief, practical, and highly developer-focused."
        )
        
        # Build prompt messages thread
        history = [
            {"role": "user", "content": prompt_text}
        ]
        
        def on_api_response(success, response_text):
            # Safe GUI updates from threads
            self.root.after(0, lambda: self._handle_api_reply(success, response_text))
            
        self._call_gemini_api_async(key, system_instruction, history, on_api_response)

    def _handle_api_reply(self, success, response_text):
        # Remove the "Thinking..." line first
        self.ai_chat_log.config(state=tk.NORMAL)
        # Search and delete last 3 lines
        end_idx = self.ai_chat_log.index("end-1c")
        self.ai_chat_log.delete(f"{end_idx} -2 lines", tk.END)
        self.ai_chat_log.config(state=tk.DISABLED)
        
        if success:
            self._append_ai_message("Copilot", response_text)
        else:
            self._append_ai_message("Copilot", f"❌ Request Failed:\\n{response_text}")

    def _call_gemini_api_async(self, api_key, system_instruction, chat_history, callback):
        def thread_target():
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={api_key}"
            contents = []
            for m in chat_history:
                contents.append({
                    "role": "model" if m["role"] == "assistant" else "user",
                    "parts": [{"text": m["content"]}]
                })
            payload = {
                "contents": contents,
                "systemInstruction": {
                    "parts": [{"text": system_instruction}]
                }
            }
            try:
                data_bytes = json.dumps(payload).encode("utf-8")
                req = urllib.request.Request(url, data=data_bytes, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req) as resp:
                    resp_data = json.loads(resp.read().decode("utf-8"))
                    text = "Unable to process content."
                    try:
                        parts = resp_data["candidates"][0]["content"]["parts"]
                        if parts:
                            text = parts[0]["text"]
                    except:
                        pass
                    callback(True, text)
            except urllib.error.HTTPError as he:
                try:
                    err_txt = json.loads(he.read().decode("utf-8"))["error"]["message"]
                except:
                    err_txt = f"HTTP Error {he.code}"
                callback(False, err_txt)
            except Exception as e:
                callback(False, str(e))
            
        threading.Thread(target=thread_target, daemon=True).start()


def main():
    root = tk.Tk()
    app = BatchEditorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
