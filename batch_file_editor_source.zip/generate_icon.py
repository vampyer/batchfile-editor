from PIL import Image, ImageDraw
import os

size = 256
im = Image.new('RGBA', (size, size), (18, 24, 46, 255))
d = ImageDraw.Draw(im)

# soft radial glow background
for y in range(size):
    for x in range(size):
        dx = x - size * 0.5
        dy = y - size * 0.45
        dist = (dx * dx + dy * dy) ** 0.5
        if dist < 110:
            alpha = int(max(0, 48 * (1 - dist / 110)))
            d.point((x, y), fill=(46, 92, 160, alpha))

# wings
left_wing = [(50, 156), (92, 96), (140, 124), (126, 160), (84, 182)]
right_wing = [(206, 156), (164, 96), (116, 124), (130, 160), (172, 182)]
wing_fill = (255, 201, 72, 255)
wing_outline = (170, 110, 38, 255)

d.polygon(left_wing, fill=wing_fill)
d.polygon(right_wing, fill=wing_fill)
d.line(left_wing + [left_wing[0]], fill=wing_outline, width=4)
d.line(right_wing + [right_wing[0]], fill=wing_outline, width=4)

# 3D body
body = [(116, 132), (140, 132), (150, 188), (138, 212), (120, 212), (108, 188)]
d.polygon(body, fill=(255, 178, 52, 255), outline=wing_outline)

d.ellipse([(122, 104), (138, 120)], fill=(255, 232, 138, 255), outline=wing_outline)
d.ellipse([(118, 144), (142, 168)], fill=(255, 238, 118, 255), outline=wing_outline)

# face and eyes
left_eye = [(124, 108), (130, 114)]
right_eye = [(132, 108), (138, 114)]
d.ellipse(left_eye, fill=(28, 18, 12, 255))
d.ellipse(right_eye, fill=(28, 18, 12, 255))

d.polygon([(118, 152), (124, 170), (128, 154), (132, 170), (138, 152)], fill=(72, 38, 20, 255))

# highlight lines
highlight_color = (255, 245, 180, 150)
d.line([(108, 152), (150, 152)], fill=highlight_color, width=2)
d.line([(88, 164), (122, 138)], fill=highlight_color, width=2)
d.line([(184, 164), (150, 138)], fill=highlight_color, width=2)

logo_path = 'bat_logo.png'
icon_path = 'bat_file_explorer.ico'
im.save(logo_path, format='PNG')
im.save(icon_path, sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)])
print('Logo created:', os.path.abspath(logo_path))
print('Icon created:', os.path.abspath(icon_path))